﻿using System.Net;

namespace SharpAdbClient.Tests
{
    /// <summary>
    /// Used by the <see cref="TcpSocketTests.CreateUnsupportedSocketTest"/> test.
    /// </summary>
    internal class CustomEndPoint : EndPoint
    {
    }
}
